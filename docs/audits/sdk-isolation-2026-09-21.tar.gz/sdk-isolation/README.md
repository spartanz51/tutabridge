# SDK isolation experiment — 2026-09-21

Official SDK pinned to aea5846b93a1412451e885bf99002401c3b087e8 (359.260904.0).
No SDK patches. Extracted event bus (including heartbeat) and MailSetEntry codec
unchanged; folder tree moved behind a local extension trait with local fixtures.
MOVE and draft reader compile against public SDK APIs only.
43 unit tests pass (28 event bus, 7 folders, 8 identifiers).
No live network operation, no account, no full bridge integration test.
Draft and MOVE have compile evidence only, not runtime parity evidence.
Draft decoder deliberately retains the existing algorithm; it does not fix AEAD.

Reproduce from the archived sources:

```sh
git clone --no-checkout https://github.com/tutao/tutanota.git upstream
git -C upstream sparse-checkout set tuta-sdk/rust test
git -C upstream checkout --detach aea5846b93a1412451e885bf99002401c3b087e8
cargo test --locked
```

The snapshot has a Cargo.lock. It uses current resolved dependencies and does
not certify the bridge's MSRV. Sources derive from the GPL-licensed bridge SDK
patches; this is a local experiment, not a published independent package.
