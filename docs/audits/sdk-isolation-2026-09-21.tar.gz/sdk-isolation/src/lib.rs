pub use tutasdk::{date, util, entities, CustomId, GeneratedId};
pub mod event_bus;
pub mod mail_set_entry_id;
pub mod folder_system;
use tutasdk::{LoggedInSdk, IdTupleGenerated, ApiCallError};
use tutasdk::entities::generated::tutanota::MoveMailData;
use tutasdk::services::generated::tutanota::MoveMailService;
/// Original MOVE algorithm extracted into a consumer crate; no SDK patch.
pub async fn move_mails(sdk: &LoggedInSdk, mut mails: Vec<IdTupleGenerated>, target_folder: IdTupleGenerated) -> Result<(), ApiCallError> {
 mails.dedup();
 for chunk in mails.chunks(50) {
  sdk.get_service_executor().post::<MoveMailService>(MoveMailData {
   _format: 0, moveReason: None, targetFolder: target_folder.clone(), mails: chunk.to_vec(), excludeMailSet: None,
  }, Default::default()).await?;
 }
 Ok(())
}

/// Compile probe: draft reading with public SDK facilities only.
pub async fn load_mail_details_draft(sdk: &LoggedInSdk, mail: &tutasdk::entities::generated::tutanota::Mail) -> Result<tutasdk::entities::generated::tutanota::MailDetails, ApiCallError> {
 use tutasdk::entities::{Entity, entity_facade::{EntityFacade, EntityFacadeImpl}};
 use tutasdk::entities::generated::tutanota::MailDetailsDraft;
 use tutasdk::crypto::crypto_facade::ResolvedSessionKey;
 use crypto_primitives::randomizer_facade::RandomizerFacade;
 if mail.mailDetails.is_some() { return Err(ApiCallError::internal("not a draft".into())); }
 let id = mail.mailDetailsDraft.as_ref().ok_or_else(|| ApiCallError::internal("missing draft id".into()))?;
 let enc_key = mail._ownerEncSessionKey.as_ref().ok_or_else(|| ApiCallError::internal("missing session key".into()))?;
 let owner = mail._ownerGroup.as_ref().ok_or_else(|| ApiCallError::internal("missing owner".into()))?;
 let version = mail._ownerKeyVersion.unwrap_or(0).unsigned_abs();
 let client = sdk.mail_facade().get_crypto_entity_client();
 let group_key = client.get_crypto_facade().get_key_loader_facade()
  .load_sym_group_key(owner, version, None).await.map_err(|e| ApiCallError::internal(format!("{e}")))?;
 let session_key = group_key.decrypt_aes_key(enc_key).map_err(|e| ApiCallError::internal(format!("{e}")))?;
 let entity_client = sdk.get_entity_client();
 let type_ref = MailDetailsDraft::type_ref();
 let parsed = entity_client.load(&type_ref, id).await?;
 let model = entity_client.resolve_server_type_ref(&type_ref)?;
 let facade = EntityFacadeImpl::new(sdk.type_model_provider.clone(), RandomizerFacade::from_core(rand_core::OsRng));
 let decrypted = facade.decrypt_and_map(&model, parsed, ResolvedSessionKey {
  session_key, owner_enc_session_key: enc_key.clone(), owner_key_version: version, sender_identity_pub_key: None,
 })?;
 let draft: MailDetailsDraft = sdk.instance_mapper.parse_entity(decrypted)
  .map_err(|e| ApiCallError::internal(format!("{e}")))?;
 Ok(draft.details)
}

#[cfg(test)] mod fixtures;
