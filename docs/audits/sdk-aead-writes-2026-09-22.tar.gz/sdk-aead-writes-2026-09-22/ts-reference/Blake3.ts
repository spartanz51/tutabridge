import { blake3 } from "../internal/noble-hashes-2.0.1.js"
import sjcl from "../internal/sjcl.js"
import { CryptoError } from "@tutao/crypto/error"
import { stringToUtf8Uint8Array } from "@tutao/utils"

import { MacTag } from "../CryptoTypes"

export const DEFAULT_BLAKE3_OUTPUT_LENGTH_BYTES = 32

/**
 * Compute a 32 byte BLAKE3 hash.
 */
export function blake3Hash(data: Uint8Array<ArrayBuffer>): any {
	return blake3(data, { dkLen: DEFAULT_BLAKE3_OUTPUT_LENGTH_BYTES })
}

/**
 * Create a 32 byte BLAKE3 tag over the given data using the given key.
 */
export function blake3Mac(keyBytes: Uint8Array<ArrayBuffer>, data: Uint8Array<ArrayBuffer>): MacTag {
	return blake3(data, { dkLen: DEFAULT_BLAKE3_OUTPUT_LENGTH_BYTES, key: keyBytes }) as MacTag
}

/**
 * Verify a BLAKE3 tag against the given data and key.
 * @throws CryptoError if the tag does not match the data and key.
 */
export function blake3MacVerify(keyBytes: Uint8Array<ArrayBuffer>, data: Uint8Array<ArrayBuffer>, tag: MacTag): void {
	const computedTag = blake3Mac(keyBytes, data)
	const tagMatches: boolean = sjcl.bitArray.equal(computedTag, tag)
	if (!tagMatches) {
		throw new CryptoError("invalid mac")
	}
}

/**
 * Derive key bytes from the given input key material and context
 * @param inputKeyMaterial Input Key Material
 * @param context
 * @param desiredLengthBytes
 */
export function blake3Kdf(inputKeyMaterial: Uint8Array<ArrayBuffer>, context: string, desiredLengthBytes: number): Uint8Array<ArrayBuffer> {
	return blake3(inputKeyMaterial, { dkLen: desiredLengthBytes, context: stringToUtf8Uint8Array(context) })
}
