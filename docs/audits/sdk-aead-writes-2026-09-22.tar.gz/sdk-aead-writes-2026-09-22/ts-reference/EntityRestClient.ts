import { DEFAULT_REST_CLIENT_OPTIONS, type RestClient } from "@tutao/rest-client"
import { HttpMethod, MediaType, RestTextBody } from "../rest-client/types"
import {
	ClientTypeModel,
	EntityTypeEnum,
	expandId,
	LOAD_MULTIPLE_LIMIT,
	POST_MULTIPLE_INDIVIDUAL_POST_FALLBACK_THRESHOLD,
	POST_MULTIPLE_LIMIT,
	TypeRef,
} from "../meta"
import { SessionKeyNotFoundError } from "@tutao/crypto/error"
import {
	assert,
	assertNotNull,
	Category,
	downcast,
	isNotEmpty,
	isNotNull,
	lazy,
	Mapper,
	Nullable,
	ofClass,
	promiseMap,
	splitInChunks,
	syncMetrics,
} from "@tutao/utils"
import { EnvProvider, ProgrammingError } from "@tutao/app-env"
import { SetupMultipleError } from "./error/SetupMultipleError"
import { BlobAccessTokenFacade } from "./BlobAccessTokenFacade.js"
import {
	DecryptedParsedInstance,
	ensureIsPersistentType,
	EntityAdapter,
	InstancePipeline,
	LoggedInUserProvider,
	OwnerEncSessionKeyProvider,
	OwnerKeyProvider,
	PatchGenerator,
	SessionKeyResolver,
	TypeModelResolver,
} from "@tutao/instance-pipeline"
import { CryptoNetworkHelper } from "./CryptoNetworkHelper"
import { Entity, ListElementEntity, PersistentEntity, ServerTypeModel } from "@tutao/meta"
import { PersistenceResourcePostReturn, PersistenceResourcePostReturnTypeRef } from "@tutao/entities/base"
import { createInstanceKdfNonce, createTypeInfo, PatchListTypeRef } from "@tutao/entities/sys"
import { EntityUpdateData } from "../instance-pipeline/utils/EntityUpdateUtils"
import { BlobServerUrl } from "@tutao/entities/storage"
import { EntityRestInterface } from "./EntityRestCacheInterface"
import {
	ConnectionError,
	InternalServerError,
	isOfflineError,
	LoginIncompleteError,
	NotAuthenticatedError,
	NotAuthorizedError,
	NotFoundError,
	PayloadTooLargeError,
} from "@tutao/rest-client/error"
import {
	AesKey,
	cryptoUtils,
	generateKdfNonce,
	KdfNonce,
	makeNullableSubKeyInfoWithSessionKeyCbcThenHmac,
	SubKeyInfo,
	SubKeyInfoWithGroupKeyAead,
	SymmetricEncryptionScheme,
	validateKdfNonceLength,
	VersionedKey,
} from "@tutao/crypto"
import { EntityUtils } from "../instance-pipeline/EntityUtils"
import { IncomingServerJson, OutgoingServerJson } from "../instance-pipeline/TypeMapper"
import {
	DEFAULT_ENTITY_RESTCLIENT_ERASE_OPTIONS,
	DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	DEFAULT_ENTITY_RESTCLIENT_UPDATE_OPTIONS,
	EntityRestClientEraseOptions,
	EntityRestClientLoadOptions,
	EntityRestClientSetupOptions,
	EntityRestClientUpdateOptions,
} from "../instance-pipeline/RestClientOptions"
import { isNull } from "../utils/Utils"

EnvProvider.assertWorkerOrNode()

export interface EntityMigrator {
	/**
	 * Takes a freshly JSON-parsed, unmapped object and apply migrations as necessary
	 * @param typeRef
	 * @param data
	 * @return the unmapped and still encrypted instance
	 */
	applyMigrations(typeRef: TypeRef<Entity>, data: EntityAdapter): Promise<EntityAdapter>
}

type PreparedRestRequestParams = {
	path: string
	queryParams: Nullable<Dict>
	headers: Dict
	clientTypeModel: ClientTypeModel
}

/**
 * Result object returned after attempting to post multiple entities.
 */
type PostMultipleHandlerResult<T extends PersistentEntity> = {
	createdIds: Id[]
	errors: Nullable<Error[]>
	failedInstances: Nullable<T[]>
}

/**
 * Retrieves the instances from the backend (db) and converts them to entities.
 *
 * Part of this process is
 * * the decryption for the returned instances (GET) and the encryption of all instances before they are sent (POST, PUT)
 * * the injection of aggregate instances for the returned instances (GET)
 * * caching for retrieved instances (GET)
 *
 */
export class EntityRestClient implements EntityRestInterface {
	private readonly TAG = "[EntityRestClient]"

	get _crypto(): CryptoNetworkHelper {
		return this.lazyCrypto()
	}

	private readonly patchGenerator: PatchGenerator
	constructor(
		private readonly authDataProvider: LoggedInUserProvider,
		private readonly restClient: RestClient,
		private readonly lazyCrypto: () => CryptoNetworkHelper,
		public readonly instancePipeline: InstancePipeline,
		private readonly blobAccessTokenFacade: BlobAccessTokenFacade,
		private readonly typeModelResolver: TypeModelResolver,
		private readonly sessionKeyResolver: lazy<SessionKeyResolver>,
		private readonly entityMigrator: lazy<EntityMigrator>,
	) {
		this.patchGenerator = new PatchGenerator(instancePipeline)
	}

	async loadParsedInstance<T extends PersistentEntity>(
		typeRef: TypeRef<T>,
		id: T["_id"],
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<DecryptedParsedInstance> {
		const tm = syncMetrics?.beginMeasurement(Category.LoadRest)
		const { listId, elementId } = expandId(id)
		const { path, queryParams, headers } = await this._validateAndPrepareRestRequest(
			typeRef,
			listId,
			elementId,
			opts.queryParams,
			opts.extraHeaders,
			opts.ownerKeyProvider,
			null,
		)
		const json = await this.restClient.request(path, HttpMethod.GET, {
			...DEFAULT_REST_CLIENT_OPTIONS,
			queryParams,
			headers,
			responseType: MediaType.Json,
			baseUrl: opts.baseUrl,
		})
		const serverTypeModel = await this.typeModelResolver.resolveServerTypeReference(typeRef)
		const incomingServerJson = IncomingServerJson.expectSingleInstance(json, serverTypeModel)
		const parsedInstance = await this.instancePipeline.typeMapper.parseServerJson(incomingServerJson)

		const entityAdapter = await EntityAdapter.fromEncryptedParsedInstance(
			parsedInstance,
			this.instancePipeline.modelMapper,
			this.instancePipeline.cryptoMapper,
		)
		const migratedEntity = await this.entityMigrator().applyMigrations(typeRef, entityAdapter)
		const sessionKey = await this.sessionKeyResolver().resolveSessionKeyWithOwnerKeyProvider(opts.ownerKeyProvider, migratedEntity)
		const decrypted = await this.instancePipeline.cryptoMapper.decryptParsedInstance(
			migratedEntity.getWrappedEncryptedInstance(),
			sessionKey,
			validateKdfNonceLength(migratedEntity._kdfNonce),
			opts.ownerKeyProvider ?? this.instancePipeline.cryptoMapper.makeOwnerKeyProvider(migratedEntity._ownerGroup),
		)
		tm?.endMeasurement()
		return decrypted
	}

	async load<T extends PersistentEntity>(
		typeRef: TypeRef<T>,
		id: T["_id"],
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<T> {
		const parsedInstance = await this.loadParsedInstance(typeRef, id, opts)
		return await this.mapInstanceToEntity(parsedInstance)
	}

	async mapInstanceToEntity<T extends PersistentEntity>(parsedInstance: DecryptedParsedInstance): Promise<T> {
		return await this.instancePipeline.modelMapper.mapToInstance<T>(parsedInstance)
	}

	async mapInstancesToEntity<T extends PersistentEntity>(typeRef: TypeRef<T>, parsedInstances: Array<DecryptedParsedInstance>): Promise<T[]> {
		return await promiseMap(
			parsedInstances,
			async (parsedInstance) => {
				return this.mapInstanceToEntity(parsedInstance)
			},
			{
				concurrency: 5,
			},
		)
	}

	async loadParsedInstancesRange<T extends ListElementEntity>(
		typeRef: TypeRef<T>,
		listId: Id,
		start: Id,
		count: number,
		reverse: boolean,
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<Array<DecryptedParsedInstance>> {
		const rangeRequestParams = {
			start: String(start),
			count: String(count),
			reverse: String(reverse),
		}
		const { path, headers, clientTypeModel, queryParams } = await this._validateAndPrepareRestRequest(
			typeRef,
			listId,
			null,
			Object.assign(rangeRequestParams, opts.queryParams),
			opts.extraHeaders,
			opts.ownerKeyProvider,
			null,
		)
		// This should never happen if type checking is not bypassed with any
		if (clientTypeModel.type !== EntityTypeEnum.ListElement) throw new Error("only ListElement types are permitted")
		const json = await this.restClient.request(path, HttpMethod.GET, {
			...DEFAULT_REST_CLIENT_OPTIONS,
			queryParams,
			headers,
			responseType: MediaType.Json,
			baseUrl: opts.baseUrl,
			suspensionBehavior: opts.suspensionBehavior,
		})
		const serverTypeModel = await this.typeModelResolver.resolveServerTypeReference(typeRef)
		const serverJson = IncomingServerJson.expectMultipleInstance(json, serverTypeModel)
		return await this._handleLoadResult(typeRef, serverJson, opts.ownerKeyProvider ?? null)
	}

	async loadRange<T extends ListElementEntity>(
		typeRef: TypeRef<T>,
		listId: Id,
		start: Id,
		count: number,
		reverse: boolean,
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<T[]> {
		const parsedInstances = await this.loadParsedInstancesRange(typeRef, listId, start, count, reverse, opts)
		return this.mapInstancesToEntity(typeRef, parsedInstances)
	}

	async loadMultipleParsedInstances<T extends PersistentEntity>(
		typeRef: TypeRef<T>,
		listId: Id | null,
		elementIds: Array<Id>,
		ownerEncSessionKeyProvider: Nullable<OwnerEncSessionKeyProvider> = null,
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<Array<DecryptedParsedInstance>> {
		const { path, headers } = await this._validateAndPrepareRestRequest(
			typeRef,
			listId,
			null,
			opts.queryParams,
			opts.extraHeaders,
			opts.ownerKeyProvider,
			null,
		)
		const idChunks = splitInChunks(LOAD_MULTIPLE_LIMIT, elementIds)
		const clientTypeModel = await this.typeModelResolver.resolveClientTypeReference(typeRef)
		const serverTypeModel = await this.typeModelResolver.resolveServerTypeReference(typeRef)

		const loadedChunks = await promiseMap(idChunks, async (idChunk) => {
			const tm = syncMetrics?.beginMeasurement(Category.LoadMultipleRest)
			const joinedIds = idChunk.join(",")
			const queryParams = { ids: joinedIds }

			let json: string
			if (clientTypeModel.type === EntityTypeEnum.BlobElement) {
				json = await this.loadMultipleBlobElements(listId, joinedIds, headers, path, typeRef, opts)
			} else {
				json = await this.restClient.request(path, HttpMethod.GET, {
					...DEFAULT_REST_CLIENT_OPTIONS,
					queryParams,
					headers,
					responseType: MediaType.Json,
					baseUrl: opts.baseUrl,
					suspensionBehavior: opts.suspensionBehavior,
				})
			}
			tm?.endMeasurement()
			return this._handleLoadResult(
				typeRef,
				IncomingServerJson.expectMultipleInstance(json, serverTypeModel),
				opts.ownerKeyProvider ?? null,
				ownerEncSessionKeyProvider,
			)
		})
		return loadedChunks.flat()
	}

	async loadMultiple<T extends PersistentEntity>(
		typeRef: TypeRef<T>,
		listId: Id | null,
		elementIds: Array<Id>,
		ownerEncSessionKeyProvider: Nullable<OwnerEncSessionKeyProvider> = null,
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<Array<T>> {
		const parsedInstances = await this.loadMultipleParsedInstances(typeRef, listId, elementIds, ownerEncSessionKeyProvider, opts)
		return await this.mapInstancesToEntity(typeRef, parsedInstances)
	}

	private async loadMultipleBlobElements(
		archiveId: Id | null,
		idsToLoad: string,
		headers: Dict,
		path: string,
		typeRef: TypeRef<any>,
		opts: EntityRestClientLoadOptions = DEFAULT_ENTITY_RESTCLIENT_LOAD_OPTIONS,
	): Promise<string> {
		if (archiveId == null) {
			throw new Error("archiveId must be set to load BlobElementTypes")
		}
		const doBlobRequest = async (): Promise<any> => {
			const blobServerAccessInfo = await this.blobAccessTokenFacade.requestReadTokenArchive(archiveId)
			const additionalRequestParams = Object.assign(
				{},
				headers, // prevent CORS request due to non standard header usage
				{ ids: idsToLoad },
			)
			const allParams = await this.blobAccessTokenFacade.createQueryParams(blobServerAccessInfo, additionalRequestParams, typeRef)

			let serversToTry = blobServerAccessInfo.servers
			if (isNotNull(opts.baseUrl)) {
				const preferredServer = blobServerAccessInfo.servers.find((server) => server.url === opts.baseUrl) ?? null

				if (isNotNull(preferredServer)) {
					// preferredServer takes precedence over the rest
					serversToTry = [preferredServer].concat(blobServerAccessInfo.servers.filter((server) => server.url !== opts.baseUrl))
				}
			}

			return tryServers(
				serversToTry,
				async (serverUrl) =>
					this.restClient.request(path, HttpMethod.GET, {
						...DEFAULT_REST_CLIENT_OPTIONS,
						queryParams: allParams,
						headers: {}, // prevent CORS request due to non standard header usage
						responseType: MediaType.Json,
						baseUrl: serverUrl,
						noCORS: true,
						suspensionBehavior: opts.suspensionBehavior,
					}),
				`can't load instances from server `,
			)
		}
		const doEvictToken = (): void => this.blobAccessTokenFacade.evictArchiveToken(archiveId)

		return doBlobRequestWithRetry(doBlobRequest, doEvictToken)
	}

	async _handleLoadResult<T extends PersistentEntity>(
		typeRef: TypeRef<T>,
		loadedEntities: Array<IncomingServerJson>,
		ownerKeyProvider: Nullable<OwnerKeyProvider>,
		ownerEncSessionKeyProvider: Nullable<OwnerEncSessionKeyProvider> = null,
	): Promise<Array<DecryptedParsedInstance>> {
		const serverTypeModel = await this.typeModelResolver.resolveServerTypeReference(typeRef)
		return await promiseMap(
			loadedEntities,
			async (instance) => {
				const parsedInstance = await this.instancePipeline.typeMapper.parseServerJson(instance)
				let entityAdapter = await EntityAdapter.fromEncryptedParsedInstance(
					parsedInstance,
					this.instancePipeline.modelMapper,
					this.instancePipeline.cryptoMapper,
				)
				return this._decryptAndMap(
					serverTypeModel,
					entityAdapter,
					ownerKeyProvider ?? this.instancePipeline.cryptoMapper.makeOwnerKeyProvider(entityAdapter._ownerGroup),
					ownerEncSessionKeyProvider,
				)
			},
			{
				concurrency: 5,
			},
		)
	}

	async _decryptAndMap(
		serverTypeModel: ServerTypeModel,
		entityAdapter: EntityAdapter,
		ownerKeyProvider: Nullable<OwnerKeyProvider>,
		ownerEncSessionKeyProvider: Nullable<OwnerEncSessionKeyProvider> = null,
	): Promise<DecryptedParsedInstance> {
		let sessionKey: AesKey | null
		if (isNotNull(ownerEncSessionKeyProvider)) {
			const { elementId } = expandId(entityAdapter._id)

			const ownerEncSessionKey = await ownerEncSessionKeyProvider(elementId, entityAdapter)
			const ownerGroup = assertNotNull(entityAdapter._ownerGroup)

			sessionKey = await this._crypto.decryptSessionKey(ownerGroup, ownerEncSessionKey)
		} else {
			try {
				sessionKey = await this.sessionKeyResolver().resolveSessionKey(entityAdapter)
			} catch (e) {
				if (e instanceof SessionKeyNotFoundError) {
					console.log("could not resolve session key", e, e.message, e.stack)
					sessionKey = null // will result in _errors being set on the instance
				} else {
					throw e
				}
			}
		}
		return await this.instancePipeline.cryptoMapper.decryptParsedInstance(
			entityAdapter.getWrappedEncryptedInstance(),
			sessionKey,
			validateKdfNonceLength(entityAdapter._kdfNonce),
			ownerKeyProvider,
		)
	}

	async setup<T extends PersistentEntity>(
		listId: Id | null,
		instance: T,
		extraHeaders: Nullable<Dict>,
		options: Nullable<EntityRestClientSetupOptions> = null,
	): Promise<Id | null> {
		const typeRef = instance._type
		const { clientTypeModel, path, headers, queryParams } = await this._validateAndPrepareRestRequest(
			typeRef,
			listId,
			null,
			null,
			extraHeaders,
			null,
			options?.ownerKey ?? null,
		)

		if (clientTypeModel.type === EntityTypeEnum.ListElement) {
			assert(isNotNull(listId), "List Id must be defined for LETs")
		} else if (clientTypeModel.type === EntityTypeEnum.Element) {
			assert(isNull(listId), "List Id must not be defined for ETs")
		} else {
			assert(false, `EntityRestClient should only be used for Elements or ListElements. Got: ${clientTypeModel.type}`)
		}
		const subKeyInfo = await this.getSubKeyInfoOnSetup(options?.ownerKey ?? null, instance, clientTypeModel)
		const encryptedParsedInstance = await this.instancePipeline.mapAndEncryptWithSubKeyInfo(instance, subKeyInfo)
		const outgoingJson = await this.instancePipeline.typeMapper.makeServerJson(encryptedParsedInstance)
		const persistencePostReturn: string = await this.restClient.request(path, HttpMethod.POST, {
			...DEFAULT_REST_CLIENT_OPTIONS,
			baseUrl: options?.baseUrl ?? null,
			queryParams,
			headers,
			body: new RestTextBody(outgoingJson.getJsonRepresentation()),
			responseType: MediaType.Json,
		})

		const persistencePostReturnTypeModel = await this.typeModelResolver.resolveServerTypeReference(PersistenceResourcePostReturnTypeRef)
		const postReturnJson = IncomingServerJson.expectSingleInstance(persistencePostReturn, persistencePostReturnTypeModel)
		const parsedPersistencePostReturn = await this.instancePipeline.typeMapper.parseServerJson(postReturnJson)
		return parsedPersistencePostReturn.getAttributeByNameOrNull("generatedId")?.getNullWhenNull()?.asId() ?? null
	}

	/**
	 * Recursively posts a chunk of entities with retry logic.
	 *
	 * If a payload is too large, it splits the chunk in half and retries.
	 * If the chunk size drops below the fallback threshold, it switches to individual entity requests.
	 *
	 * @template T - The type of the entity being processed.
	 *
	 * @param listId
	 * @param instances
	 * @returns {Promise<PostMultipleHandlerResult<T>>} An object containing successfully created IDs, errors, and failed instances.
	 * @throws {ConnectionError} If an offline error is encountered during the process.
	 * @throws {SetupMultipleError} If any other unrecoverable errors occur during setup.
	 */
	async setupMultiple<T extends PersistentEntity>(listId: Id | null, instances: Array<T>): Promise<Array<Id>> {
		if (instances.length < 1) {
			return []
		}

		const { clientTypeModel, path, headers } = await this._validateAndPrepareRestRequest(instances[0]._type, listId, null, null, null, null, null)
		const persistencePostReturnTypeModel = await this.typeModelResolver.resolveServerTypeReference(PersistenceResourcePostReturnTypeRef)

		if (clientTypeModel.type === EntityTypeEnum.ListElement) {
			assert(isNotNull(listId), "List Id must be defined for LETs")
		} else if (clientTypeModel.type === EntityTypeEnum.Element) {
			assert(isNull(listId), "List Id must not be defined for ETs")
		} else {
			assert(false, `EntityRestClient should only be used for Elements or ListElements. Got: ${clientTypeModel.type}`)
		}

		const instanceChunks = splitInChunks(POST_MULTIPLE_LIMIT, instances)
		const mapResult = await promiseMap(instanceChunks, (chunk) =>
			this.postMultipleHandlerWithRetry(listId as Id, chunk, path, headers, persistencePostReturnTypeModel, clientTypeModel),
		)

		const createdIds = mapResult.flatMap((res) => res.createdIds)
		const errors = mapResult.flatMap((res) => res.errors ?? [])
		const failedInstances = mapResult.flatMap((res) => res.failedInstances ?? [])

		console.log(this.TAG, "setupMultiple results:", `\nSuccessful entities: ${createdIds.length}`, `\nTotal errors: ${errors.length}`)

		if (errors.length > 0) {
			if (errors.some(isOfflineError)) {
				throw new ConnectionError("Setup multiple entities failed")
			}
			throw new SetupMultipleError<T>("Setup multiple entities failed", errors, failedInstances)
		} else {
			return createdIds
		}
	}

	/**
	 * Recursively posts a chunk of entities with retry logic.
	 *
	 * @template T - The type of the entity being processed.
	 *
	 * @param listId
	 * @param {T[]} instanceChunk - An array of entity instances to be posted in this batch.
	 * @param path
	 * @param headers
	 * @param persistencePostReturnTypeModel
	 * @param clientTypeModel
	 */
	private async postMultipleHandlerWithRetry<T extends PersistentEntity>(
		listId: Id,
		instanceChunk: T[],
		path: string,
		headers: Dict,
		persistencePostReturnTypeModel: ServerTypeModel,
		clientTypeModel: ClientTypeModel,
	): Promise<PostMultipleHandlerResult<T>> {
		console.log(this.TAG, "postMultipleHandlerWithRetry", `\nEntities in the chunk: ${instanceChunk.length}\nFirst entities Id: ${instanceChunk[0]._id}`)

		try {
			const outgoingServerJsons = await promiseMap(instanceChunk, async (instance) => {
				instance._ownerEncSessionKey = null
				const sk = await this._crypto.setNewOwnerEncSessionKey(clientTypeModel, instance, null)
				const encEntity = await this.instancePipeline.mapAndEncryptToParsedInstance(downcast<TypeRef<Entity>>(instance._type), instance, sk)
				return this.instancePipeline.typeMapper.makeServerJson(encEntity)
			})

			// informs the server that this is a POST_MULTIPLE request
			const queryParams = {
				count: String(instanceChunk.length),
			}

			const persistencePostReturn = await this.restClient.request(path, HttpMethod.POST, {
				...DEFAULT_REST_CLIENT_OPTIONS,
				queryParams,
				headers,
				body: new RestTextBody(OutgoingServerJson.getJsonRepresentationOfMultiple(outgoingServerJsons)),
				responseType: MediaType.Json,
			})

			const untypedPersistencePostReturn = IncomingServerJson.expectMultipleInstance(persistencePostReturn, persistencePostReturnTypeModel)
			const createdIds = await this.parseSetupMultiple(untypedPersistencePostReturn)

			console.log(
				this.TAG,
				"postMultipleHandlerWithRetry",
				`Successfully retried chunk ${instanceChunk[0]._id} resulting in ${createdIds.length} created entities`,
			)

			return {
				createdIds,
				errors: null,
				failedInstances: null,
			}
		} catch (e) {
			if (e instanceof PayloadTooLargeError) {
				return await this.handlePayloadTooLargeForSetupMultiple(
					instanceChunk,
					e,
					listId,
					path,
					headers,
					persistencePostReturnTypeModel,
					clientTypeModel,
				)
			} else {
				// Unknown error without a proper handling
				console.error(this.TAG, "postMultipleHandlerWithRetry", `Unknown error when retrying chunk ${instanceChunk[0]._id}`)
				return {
					createdIds: [],
					errors: [e],
					failedInstances: instanceChunk,
				}
			}
		}
	}

	private async handlePayloadTooLargeForSetupMultiple<T extends PersistentEntity>(
		instanceChunk: T[],
		e: PayloadTooLargeError,
		listId: string,
		path: string,
		headers: Dict,
		persistencePostReturnTypeModel: ServerTypeModel,
		clientTypeModel: ClientTypeModel,
	): Promise<PostMultipleHandlerResult<T>> {
		console.warn(
			this.TAG,
			'setupMultiple failed with "Payload too large".',
			`\nEntities in the failed chunk: ${instanceChunk.length}`,
			`\nFirst entities Id: ${instanceChunk[0]._id}`,
			`\nOriginal error: ${e}`,
		)

		const createdIds: Id[] = []
		const errors: Error[] = []
		const failedInstances: T[] = []

		// Fallback to individual requests if chunk size is small enough
		if (instanceChunk.length <= POST_MULTIPLE_INDIVIDUAL_POST_FALLBACK_THRESHOLD) {
			console.log(this.TAG, `Retrying with individual entity post request fallback.\nEntities left: ${instanceChunk.length}`)

			const individualResults = await Promise.allSettled(
				instanceChunk.map(async (instance) => {
					// {@link setup} method will re-assign a session key and make a single post request to persist the provided entity
					instance._ownerEncSessionKey = null
					const createdEntityId = await this.setup(listId, instance, null, null)
					return assertNotNull(createdEntityId)
				}),
			)

			for (const [index, result] of individualResults.entries()) {
				if (result.status === "fulfilled") {
					createdIds.push(result.value)
				} else {
					const err = result.reason instanceof Error ? result.reason : new Error(String(result.reason))
					console.error("Error on individual entity setup", err)
					errors.push(err)
					failedInstances.push(instanceChunk[index])
				}
			}

			return { createdIds, errors, failedInstances }
		}

		// Otherwise, split chunk in half and retry recursively
		const smallerChunks = splitInChunks(Math.floor(instanceChunk.length / 2), instanceChunk)
		const results = await Promise.allSettled(
			smallerChunks.map((chunk) => {
				console.log(this.TAG, `Retrying with smaller chunk. \nFirst entity Id of new chunk: ${chunk[0]._id}`)
				return this.postMultipleHandlerWithRetry(listId, chunk, path, headers, persistencePostReturnTypeModel, clientTypeModel)
			}),
		)
		for (const retryResult of results) {
			if (retryResult.status === "fulfilled") {
				createdIds.push(...retryResult.value.createdIds)

				if (retryResult.value.errors !== null) {
					errors.push(...retryResult.value.errors)
					failedInstances.push(...(retryResult.value.failedInstances ?? []))
				}
			}
		}

		return {
			createdIds,
			errors,
			failedInstances,
		}
	}

	async update<T extends PersistentEntity>(instance: T, options: EntityRestClientUpdateOptions = DEFAULT_ENTITY_RESTCLIENT_UPDATE_OPTIONS): Promise<void> {
		const { listId, elementId } = expandId(assertNotNull(instance._id, "Id must be defined while updating an instance"))
		const { path, queryParams, headers } = await this._validateAndPrepareRestRequest(
			instance._type,
			listId,
			elementId,
			null,
			null,
			options?.ownerKeyProvider,
			null,
		)
		// map and encrypt instance._original and the instance
		const originalParsedInstance = await this.instancePipeline.modelMapper.mapToDecryptedInstance(assertNotNull(instance._original))
		const parsedInstance = await this.instancePipeline.modelMapper.mapToDecryptedInstance(instance)
		const subKeyInfo = await this.getSubKeyInfoOnUpdate(options?.ownerKeyProvider, instance)
		const modifiedEncryptedInstance = await this.instancePipeline.cryptoMapper.encryptParsedInstance(parsedInstance, subKeyInfo)

		// figure out differing fields and build the PATCH request payload
		const patchList = await this.patchGenerator.computePatchPayload(originalParsedInstance, parsedInstance, modifiedEncryptedInstance)
		if (isNotEmpty(patchList.patches)) {
			// PatchList has no encrypted fields (sk == null)
			const patchPayload = await this.instancePipeline.mapAndEncrypt(PatchListTypeRef, patchList, null)
			await this.restClient.request(path, HttpMethod.PATCH, {
				...DEFAULT_REST_CLIENT_OPTIONS,
				baseUrl: options?.baseUrl ?? null,
				queryParams,
				headers,
				body: new RestTextBody(patchPayload.getJsonRepresentation()),
				responseType: MediaType.Json,
			})
		}
	}

	private async getSubKeyInfoOnSetup<T extends PersistentEntity>(
		ownerKey: VersionedKey | null,
		instance: T,
		clientTypeModel: ClientTypeModel,
	): Promise<Nullable<SubKeyInfo>> {
		if (this.authDataProvider.getDefaultSymmetricEncryptionScheme() === SymmetricEncryptionScheme.AesCbc) {
			const sessionKey: Nullable<AesKey> = await this._crypto.setNewOwnerEncSessionKey(clientTypeModel, instance, ownerKey)
			return makeNullableSubKeyInfoWithSessionKeyCbcThenHmac(sessionKey)
		} else {
			if (ownerKey == null) {
				if (instance._ownerGroup == null) {
					throw new ProgrammingError("This instance has no owner group")
				}
				ownerKey = await this._crypto.getCurrentSymGroupKey(instance._ownerGroup)
			}
			if (instance._kdfNonce != null) {
				// why do you have a KDF nonce at this point? is the instance a deep copy?
				console.log(`overwriting KDF nonce previously found on instance of type ${instance._type} with ID ${instance._id}`)
			}

			const kdfNonce: KdfNonce = generateKdfNonce()
			instance._kdfNonce = kdfNonce
			return new SubKeyInfoWithGroupKeyAead(ownerKey, kdfNonce)
		}
	}

	private async getSubKeyInfoOnUpdate<T extends PersistentEntity>(ownerKeyProvider: Nullable<OwnerKeyProvider>, instance: T): Promise<Nullable<SubKeyInfo>> {
		if (this.authDataProvider.getDefaultSymmetricEncryptionScheme() === SymmetricEncryptionScheme.AesCbc) {
			const sessionKey = await this.sessionKeyResolver().resolveSessionKeyWithOwnerKeyProvider(ownerKeyProvider, instance)
			return makeNullableSubKeyInfoWithSessionKeyCbcThenHmac(sessionKey)
		} else {
			let ownerKey: VersionedKey
			if (isNotNull(ownerKeyProvider)) {
				let ownerKeyVersion = cryptoUtils.parseKeyVersion(instance._ownerKeyVersion ?? "0")
				ownerKey = {
					object: await ownerKeyProvider(ownerKeyVersion),
					version: ownerKeyVersion,
				}
			} else {
				if (instance._ownerGroup == null) {
					throw new ProgrammingError("This instance has no owner group")
				}
				ownerKey = await this._crypto.getCurrentSymGroupKey(instance._ownerGroup)
			}
			let kdfNonce: KdfNonce
			if (instance._kdfNonce == null) {
				const [instanceList, instanceId] = instance._id
				const application = instance._type.app
				const typeId = instance._type.typeId.toString()
				const typeInfo = createTypeInfo({ application, typeId })
				const out = await this._crypto.postUpdateKdfNonceService(
					createInstanceKdfNonce({ kdfNonce: generateKdfNonce(), instanceId, instanceList, typeInfo }),
				)
				kdfNonce = validateKdfNonceLength(out.kdfNonce)
				instance._kdfNonce = kdfNonce
			} else {
				kdfNonce = validateKdfNonceLength(instance._kdfNonce)
			}
			return new SubKeyInfoWithGroupKeyAead(ownerKey, kdfNonce)
		}
	}

	async erase<T extends PersistentEntity>(instance: T, options: EntityRestClientEraseOptions = DEFAULT_ENTITY_RESTCLIENT_ERASE_OPTIONS): Promise<void> {
		const { listId, elementId } = expandId(instance._id)
		const { path, queryParams, headers } = await this._validateAndPrepareRestRequest(
			instance._type,
			listId,
			elementId,
			null,
			options?.extraHeaders ?? null,
			null,
			null,
		)
		await this.restClient.request(path, HttpMethod.DELETE, {
			...DEFAULT_REST_CLIENT_OPTIONS,
			queryParams,
			headers,
		})
	}

	async eraseMultiple<T extends PersistentEntity>(
		listId: string,
		instances: T[],
		options: Nullable<EntityRestClientEraseOptions> = DEFAULT_ENTITY_RESTCLIENT_ERASE_OPTIONS,
	): Promise<void> {
		if (instances.length === 0) {
			return
		}

		const instancesIdsString = instances.map((it) => expandId(it._id).elementId).join(",")
		const type = instances[0]._type

		const { path, queryParams, headers } = await this._validateAndPrepareRestRequest(
			type,
			listId,
			null,
			{ ids: instancesIdsString },
			options?.extraHeaders ?? null,
			null,
			null,
		)

		await this.restClient.request(path, HttpMethod.DELETE, {
			...DEFAULT_REST_CLIENT_OPTIONS,
			queryParams,
			headers,
		})
	}

	async _validateAndPrepareRestRequest(
		typeRef: TypeRef<any>,
		listId: Id | null,
		elementId: Id | null,
		queryParams: Nullable<Dict>,
		extraHeaders: Nullable<Dict>,
		ownerKeyProvider: OwnerKeyProvider | null,
		ownerKey: VersionedKey | null,
	): Promise<PreparedRestRequestParams> {
		const clientTypeModel = await this.typeModelResolver.resolveClientTypeReference(typeRef)

		ensureIsPersistentType(clientTypeModel)

		if (ownerKeyProvider == null && ownerKey == null && !this.authDataProvider.isFullyLoggedIn() && clientTypeModel.encrypted) {
			// Short-circuit before we do an actual request which we can't decrypt
			throw new LoginIncompleteError(`Trying to do a network request with encrypted entity but is not fully logged in yet, type: ${clientTypeModel.name}`)
		}

		let path = EntityUtils.typeModelToRestPath(clientTypeModel)

		if (isNotNull(listId)) {
			path += "/" + listId
		}
		if (isNotNull(elementId)) {
			path += "/" + elementId
		}

		const headers = Object.assign({}, this.authDataProvider.createAuthHeaders(), extraHeaders)

		if (Object.keys(headers).length === 0) {
			throw new NotAuthenticatedError("user must be authenticated for entity requests")
		}

		headers.v = String(clientTypeModel.version)
		if (isNotNull(clientTypeModel.dependsOnVersion)) {
			headers.dv = String(clientTypeModel.dependsOnVersion)
		}

		return {
			path,
			queryParams,
			headers,
			clientTypeModel,
		}
	}

	/**
	 * for the admin area (no cache available)
	 */
	onEntityUpdatesReceived(events: readonly EntityUpdateData[], _batchId: Id, _groupId: Id): Promise<readonly EntityUpdateData[]> {
		return Promise.resolve(events)
	}

	getRestClient(): RestClient {
		return this.restClient
	}

	private async parseSetupMultiple(result: Array<IncomingServerJson>): Promise<Array<Id>> {
		try {
			return await promiseMap(Array.from(result), async (serverJson: IncomingServerJson) => {
				const parsedInstance = await this.instancePipeline.decryptAndMap<PersistenceResourcePostReturn>(serverJson, null)
				return parsedInstance.generatedId as Id // is null for customIds
			})
		} catch (e) {
			throw new Error(`Invalid response: ${result}, ${e}`)
		}
	}
}

/**
 * Tries to run the mapper action against a list of servers. If the action resolves
 * successfully, the result is returned. In case of an ConnectionError and errors
 * that might occur only for a single blob server, the next server is tried.
 * Throws in all other cases.
 */
export async function tryServers<T>(servers: BlobServerUrl[], mapper: Mapper<string, T>, errorMsg: string): Promise<T> {
	let index = 0
	let error: Error | null = null
	for (const server of servers) {
		try {
			return await mapper(server.url, index)
		} catch (e) {
			// InternalServerError is returned when accessing a corrupted archive, so we retry
			if (e instanceof ConnectionError || e instanceof InternalServerError || e instanceof NotFoundError) {
				console.log(`${errorMsg} ${server.url}`, e)
				error = e
			} else {
				throw e
			}
		}
		index++
	}
	throw error
}

/**
 * Do a blob request and retry it in case of a NotAuthorizedError, performing some cleanup before retrying.
 *
 * This is useful for blob requests to handle expired tokens, which cah occur if the requests take a long time, the client gets suspended or paused by the OS.
 * @param doBlobRequest
 * @param doEvictTokenBeforeRetry
 */
export async function doBlobRequestWithRetry<T>(doBlobRequest: () => Promise<T>, doEvictTokenBeforeRetry: () => void): Promise<T> {
	return doBlobRequest().catch(
		// in case one of the chunks could not be uploaded because of an invalid/expired token we upload all chunks again in order to guarantee that they are uploaded to the same archive.
		// we don't have to take care of already uploaded chunks, as they are unreferenced and will be cleaned up by the server automatically.
		ofClass(NotAuthorizedError, (_) => {
			doEvictTokenBeforeRetry()
			return doBlobRequest()
		}),
	)
}
