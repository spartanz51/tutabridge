import { EventBusListener } from "../../../../app-kit/local-store/event/EventBusClient.js"
import { MailFacade } from "./facades/lazy/MailFacade.js"
import { UserFacade } from "../../../../platform-kit/base/facades/UserFacade.js"
import { EntityClient } from "../../../../platform-kit/network/EntityClient.js"
import { EnvProvider, RolloutType } from "@tutao/app-env"
import { assertNotNull, lazyAsync } from "@tutao/utils"
import { ExposedEventController } from "../main/EventController.js"
import { ConfigurationDatabase } from "./facades/lazy/ConfigurationDatabase.js"
import { KeyRotationFacade } from "../../../../platform-kit/base/base-crypto/KeyRotationFacade.js"
import { CacheManagementFacade } from "./facades/lazy/CacheManagementFacade.js"
import { RolloutFacade } from "../../../../platform-kit/base/facades/RolloutFacade"
import { GroupManagementFacade } from "../../../../platform-kit/base/facades/lazy/GroupManagementFacade"
import { SyncTracker } from "../main/SyncTracker"
import { IdentityKeyCreator } from "../../../../platform-kit/base/base-crypto/IdentityKeyCreator"
import { ReportedMailFieldMarker } from "@tutao/entities/tutanota"
import {
	GroupKeyUpdateTypeRef,
	OperationStatusUpdate,
	UserGroupKeyDistributionTypeRef,
	UserGroupRootTypeRef,
	UserTypeRef,
	WebsocketCounterData,
} from "@tutao/entities/sys"
import { idToElementId, isSameId, isSameSingleId, OperationType } from "@tutao/meta"
import { CacheSyncStatus, EntityUpdateData, isUpdateForTypeRef } from "../../../../platform-kit/instance-pipeline/utils/EntityUpdateUtils"
import { ImapImporter } from "../../../mail-app/workerUtils/imapimport/ImapImporter"

/** A bit of glue to distribute event bus events across the app. */
export class EventBusEventCoordinator implements EventBusListener {
	constructor(
		private readonly mailFacade: lazyAsync<MailFacade> | null,
		private readonly imapImporter: lazyAsync<ImapImporter> | null,
		private readonly userFacade: UserFacade,
		private readonly entityClient: EntityClient,
		private readonly eventController: ExposedEventController,
		private readonly configurationDatabase: lazyAsync<ConfigurationDatabase>,
		private readonly keyRotationFacade: KeyRotationFacade,
		private readonly cacheManagementFacade: lazyAsync<CacheManagementFacade>,
		private readonly sendError: (error: Error) => Promise<void>,
		private readonly appSpecificBatchHandling: (events: readonly EntityUpdateData[], batchId: Id, groupId: Id, isInitialSyncDone: boolean) => void,
		private readonly rolloutFacade: RolloutFacade,
		private readonly groupManagementFacade: lazyAsync<GroupManagementFacade>,
		private readonly identityKeyCreator: lazyAsync<IdentityKeyCreator>,
		private readonly syncTracker: SyncTracker,
	) {}

	async onEntityUpdatesReceived(events: readonly EntityUpdateData[], batchId: Id, groupId: Id, isInitialSyncDone: boolean): Promise<void> {
		await this.entityUpdatesReceived(events)
		await (await this.mailFacade?.())?.onEntityUpdatesReceived(events)
		await (await this.imapImporter?.())?.onEntityUpdatesReceived(events, groupId)
		await this.eventController.onEntityUpdatesReceived(events, groupId, isInitialSyncDone)
		// Call the indexer in this last step because now the processed event is stored and the indexer has a separate event queue that
		// shall not receive the event twice.
		if (!EnvProvider.isTest() && !EnvProvider.get().isAdminClient()) {
			const configurationDatabase = await this.configurationDatabase()
			await configurationDatabase.onEntityUpdatesReceived(events, batchId, groupId)
			this.appSpecificBatchHandling(events, batchId, groupId, isInitialSyncDone)
		}
	}

	/**
	 * @param markers only phishing (not spam) marker will be sent as websocket updates
	 */
	async onPhishingMarkersReceived(markers: ReportedMailFieldMarker[]) {
		;(await this.mailFacade?.())?.phishingMarkersUpdateReceived(markers)
	}

	onError(tutanotaError: Error) {
		this.sendError(tutanotaError)
	}

	onCounterChanged(counter: WebsocketCounterData) {
		this.eventController.onCountersUpdateReceived(counter)
	}

	async onSyncStatusChanged(cacheSyncStatus: CacheSyncStatus): Promise<void> {
		this.syncTracker.updateSyncStatus(cacheSyncStatus)

		if (cacheSyncStatus === CacheSyncStatus.OnlineSyncDone) {
			await this.onSyncDone()
		}
	}

	onOperationStatusUpdate(update: OperationStatusUpdate) {
		this.eventController.onOperationStatusUpdate(update)
	}

	private async entityUpdatesReceived(data: readonly EntityUpdateData[]): Promise<void> {
		// This is a compromise to not add entityClient to UserFacade which would introduce a circular dep.
		const groupKeyUpdates: IdTuple[] = [] // GroupKeyUpdates all in the same list
		const user = this.userFacade.getUser()
		if (user == null) return
		for (const update of data) {
			if (update.operation === OperationType.UPDATE && isUpdateForTypeRef(UserTypeRef, update) && isSameId(user._id, idToElementId(update.instanceId))) {
				await this.userFacade.updateUser(await this.entityClient.load(UserTypeRef, user._id))
			} else if (
				(update.operation === OperationType.CREATE || update.operation === OperationType.UPDATE) &&
				isUpdateForTypeRef(UserGroupKeyDistributionTypeRef, update) &&
				isSameSingleId(user.userGroup.group, update.instanceId)
			) {
				await (await this.cacheManagementFacade()).tryUpdatingUserGroupKey()
			} else if (update.operation === OperationType.CREATE && isUpdateForTypeRef(GroupKeyUpdateTypeRef, update)) {
				groupKeyUpdates.push([assertNotNull(update.instanceListId), update.instanceId])
			}
		}
		await this.keyRotationFacade.updateGroupMembershipsInOneList(groupKeyUpdates)
	}

	private async onSyncDone() {
		if (this.userFacade.isLeader() && !EnvProvider.get().isAdminClient()) {
			const userIdentityKeyCreationAction = {
				execute: async () => {
					const identityKeyCreator = await this.identityKeyCreator()

					try {
						await identityKeyCreator.createIdentityKeyPairForExistingUsers()
					} catch (error) {
						console.log("error when creating user identity key pair", error)
						void this.sendError(error)
					}
				},
			}
			await this.rolloutFacade.configureRollout(RolloutType.UserIdentityKeyCreation, userIdentityKeyCreationAction)

			const sharedMailboxIdentityKeyCreationAction = {
				execute: async () => {
					const identityKeyCreator = await this.identityKeyCreator()
					const groupManagementFacade = await this.groupManagementFacade()
					try {
						const teamGroups = await groupManagementFacade.loadTeamGroupIds()
						await identityKeyCreator.createIdentityKeyPairForExistingTeamGroups(teamGroups)
					} catch (error) {
						console.log(`error when creating shared mailbox identity key pairs`, error)
						void this.sendError(error)
					}
				},
			}
			await this.rolloutFacade.configureRollout(RolloutType.SharedMailboxIdentityKeyCreation, sharedMailboxIdentityKeyCreationAction)

			const processGroupKeyUpdates = {
				execute: async () => {
					try {
						const userGroupRoot = await this.entityClient.load(UserGroupRootTypeRef, idToElementId(this.userFacade.getUserGroupId()))
						const groupKeyUpdates = await this.entityClient.loadAll(GroupKeyUpdateTypeRef, assertNotNull(userGroupRoot.groupKeyUpdates).list)
						await this.keyRotationFacade.updateGroupMemberships(groupKeyUpdates)
					} catch (error) {
						console.log("error when processing a pending group key update", error)
						void this.sendError(error)
					}
				},
			}
			await this.rolloutFacade.configureRollout(RolloutType.GroupKeyUpdatePending, processGroupKeyUpdates)

			await this.rolloutFacade.processRollout(RolloutType.GroupKeyUpdatePending)
			await this.rolloutFacade.processRollout(RolloutType.UserIdentityKeyCreation)
			await this.rolloutFacade.processRollout(RolloutType.SharedMailboxIdentityKeyCreation)
			await this.rolloutFacade.processRollout(RolloutType.AdminOrUserGroupKeyRotation)
			await this.rolloutFacade.processRollout(RolloutType.OtherGroupKeyRotation)
		}

		const useAead = {
			execute: async () => {
				this.userFacade.useAeadEncryption()
			},
		}
		await this.rolloutFacade.configureRollout(RolloutType.EncryptionOfAttributesViaAead, useAead)
		await this.rolloutFacade.processRollout(RolloutType.EncryptionOfAttributesViaAead)
	}
}
